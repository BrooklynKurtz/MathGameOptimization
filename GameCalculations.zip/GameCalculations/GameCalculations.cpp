/*

This program computes the optimal solution for a math-game to be played with students learning arithmetic (but it's also kinda fun, so go ham).

The game boils down to this:

Each player starts off with four operation cards: addition, subtraction, multiplication, and division

Then each player is dealt four integer cards, each representing an integer from 1 - 10

Then, a d20 is rolled to determine the target value

Each player has two opportunities to swap out up to two of their integer cards at a time for new cards

Once each player has passed twice, the players lay down their cards to form an arithmetic expression.

They do this by selecting three of their four operations and alternating between integer and operation, like so:

    Integer - Operation - Integer - Operation - Integer = Operation - Integer

Players then evaluate the expressions. The winner is the player with the expression which evaluates closest to the target value.


This program finds the optimal arithmetic expression for a given set of integers and target value.

*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <stack>

using namespace std;

vector<int> GetIntegers() // returns integers for the game calculations, ensures that the integers fall within the correct range.
{
    int i;
    int input;
    vector<int> output;

    for (i = 0; i < 4; i++)
    {
        while (true)
        {
            cout << "Enter integer #" << i + 1 << ": ";
            cin >> input;
            cout << endl;

            if (1 <= input && input <= 10)
            {
                break;
            }

            else
            {
                cout << "Input out of range. Must be between 1 and 10, inclusive." << endl;
            }
        }

        output.push_back(input);
    }

    return output;
}

vector<vector<char>> GetOperations() // returns each combination of operations
{
    int i;
    int j;
    vector<char> operations;
    vector<char> operators = { '+', '-', '*', '/' };
    vector<vector<char>> operationsList;

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            if (i != j)
            {
                operations.push_back(operators.at(j));
            }
        }

        operationsList.push_back(operations);
        operations.clear();
    }

    return operationsList;
}

template <typename T>
vector<vector<T>> GetPermutations(vector<T> elements) // this monstrosity finds all possible permutations of a given vector input. It's recursive!
{
    vector<vector<T>> permutations;
    vector<T> remaining_elements;
    vector<vector<T>> sub_permutations;

    if (elements.size() <= 1)
    {
        permutations.push_back(elements);
        return permutations;
    }

    for (size_t i = 0; i < elements.size(); ++i)
    {
        remaining_elements = elements;
        T element = remaining_elements[i];
        remaining_elements.erase(remaining_elements.begin() + i);

        sub_permutations = GetPermutations(remaining_elements);

        for (const vector<T>& sub_permutation : sub_permutations)
        {
            vector<T> permutation;
            permutation.push_back(element);
            permutation.insert(permutation.end(), sub_permutation.begin(), sub_permutation.end());
            permutations.push_back(permutation);
        }
    }

    return permutations;
}

vector<pair<vector<int>, vector<char>>> EquationBuilder(vector<vector<int>> integers, vector<vector<char>> operations) // this function builds the monstrosity that holds the individual equations
{
    int i;
    int j;
    pair<vector<int>, vector<char>> line;
    vector<pair<vector<int>, vector<char>>> output;

    for (i = 0; i < integers.size(); i++)
    {
        for (j = 0; j < operations.size(); j++)
        {
            line.first = integers.at(i);
            line.second = operations.at(j);

            output.push_back(line);
        }
    }

    return output;
}

// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Function to determine the precedence of an operator
int Precedence(char op)
{
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

// Function to apply an operator and update the number stack
void ApplyOperator(stack<double>& numStack, char op)
{
    double operand2 = numStack.top();
    numStack.pop();
    double operand1 = numStack.top();
    numStack.pop();

    if (op == '+') numStack.push(operand1 + operand2);
    else if (op == '-') numStack.push(operand1 - operand2);
    else if (op == '*') numStack.push(operand1 * operand2);
    else if (op == '/') numStack.push(operand1 / operand2);
}

// Function to calculate the result of an expression with proper order of operations
double Evaluate(const vector<int>& integers, const vector<char>& operations)
{
    stack<double> numStack;
    stack<char> opStack;

    for (size_t i = 0; i < integers.size(); ++i)
    {
        numStack.push(static_cast<double>(integers[i]));

        if (i < operations.size())
        {
            while (!opStack.empty() && Precedence(opStack.top()) >= Precedence(operations[i]))
            {
                ApplyOperator(numStack, opStack.top());
                opStack.pop();
            }
            opStack.push(operations[i]);
        }
    }

    while (!opStack.empty())
    {
        ApplyOperator(numStack, opStack.top());
        opStack.pop();
    }

    return numStack.top();
}

// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

vector<double> EvaluateEquations(vector<pair<vector<int>, vector<char>> > equations) // this function breaks down the task of evaluating the equations, essentially creating the equations that need to be solved
{
    double result;
    vector<int> integers;
    vector<char > operations;
    vector<double> output;

    for (const auto& pair : equations)
    {
        integers = pair.first;
        operations = pair.second;

        result = Evaluate(integers, operations);
        output.push_back(result);
    }

    return output;
}

double GetTarget() // gets the target value (moved here in updates)
{
    int target;

    while (true)
    {
        cout << "Enter the target value (1 - 20): ";
        cin >> target;
        cout << endl;

        if (1 <= target && target <= 20)
        {
            break;
        }

        else
        {
            cout << "Invalid input, out of range." << endl;
        }
    }

    return 1.0 * target;
}

void FindClosestMatch(vector<double>& results, vector<pair<vector<int>, vector<char>>>& equations, double target) // finds the equation whose solution is closest to a selected target value
{
    int closestIndex = 0;
    double minDiff = abs(results[0] - target);

    for (size_t i = 1; i < results.size(); ++i)
    {
        double diff = abs(results[i] - target);
        if (diff < minDiff)
        {
            minDiff = diff;
            closestIndex = i;
        }
    }

    vector<int>& integers = equations[closestIndex].first;
    vector<char>& operations = equations[closestIndex].second;

    cout << "Closest to target value " << target << ": ";
    for (size_t i = 0; i < integers.size() - 1; ++i)
    {
        cout << integers[i] << " " << operations[i] << " ";
    }
    cout << integers.back() << " = " << results[closestIndex] << " -- " << minDiff << " away" << endl;
}

bool Continue() // simple input checker for seeing if the user wants to exit
{
    char input;

    while (true)
    {
        cout << "\n\n\nContinue? Y/N: ";
        cin >> input;

        switch (input)
        {
            case 'y':
            case 'Y':
                cout << endl;
                return true;
                break;
            case 'n':
            case 'N':
                cout << "Exiting program. . ." << endl;
                return false;
                break;
            default:
                cout << "Invalid input. Try again." << endl;
                break;
        }
    }
}

int main() // da main
{
    vector<int> integers;
    vector<vector<int>> integerPermutations;
    vector<vector<char>> operationsList;
    vector<vector<char>> operationsPermutations;
    vector<pair<vector<int>, vector<char>>> equations;  // vector of equations for each iteration
    vector<double> results;
    double target;
    bool flag = true;

    while (flag)
    {
        integers = GetIntegers();
        operationsList = GetOperations();  // get selected operations
        target = GetTarget();

        integerPermutations = GetPermutations(integers); // builds the set of integer permutations

        for (const auto& selectedOperations : operationsList) // iterates through the set of possible operations
        {
            operationsPermutations = GetPermutations(selectedOperations); // builds the set of operation permutations

            equations = EquationBuilder(integerPermutations, operationsPermutations); // builds the set of equations

            results = EvaluateEquations(equations); // evaluates the equations

            FindClosestMatch(results, equations, target); // finds the closest match to the target value
        }

        flag = Continue();
    }

    return 0;
}
